package vttp2022.paf.day26;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
