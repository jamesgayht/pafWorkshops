package vttp2022.paf.day26;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day26Application {

	public static void main(String[] args) {
		SpringApplication.run(Day26Application.class, args);
	}

}
