package vttp2022.paf.assessment.eshop.respositories;

public class OrderRepository {
	// TODO: Task 3
}
