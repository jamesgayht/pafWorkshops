package vttp2022.paf.assessment.eshop.respositories;

import java.util.Optional;

import vttp2022.paf.assessment.eshop.models.Customer;

public class CustomerRepository {

	// You cannot change the method's signature
	public Optional<Customer> findCustomerByName(String name) {
		// TODO: Task 3 

	}
}
